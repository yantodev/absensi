<!-- <style>
    @page {
        margin-top: 0.5cm;
        margin-bottom: 0.5cm;
        margin-left: 1.0cm;
        margin-right: 1.0cm;
    }
</style> -->
<!-- <img src="<?= base_url('assets/img/kop.png'); ?>"> -->
<h3 style="text-align: center;">Rekap Jurnal Bulanan</h3>
<table>
    <tr>
        <td>NBM</td>
        <td>:</td>
        <td><?= $nbm; ?></td>
    </tr>
    <tr>
        <td>Nama</td>
        <td>:</td>
        <td>
            <?php
            $result = $this->db->get_where('tbl_gukar', ['nbm' => $nbm])->row_array();
            echo $result['nama'];
            ?>
        </td>
    </tr>
    <tr>
        <td>Jabatan</td>
        <td>:</td>
        <td>
            <?php
            $result = $this->db->get_where('tbl_gukar', ['nbm' => $nbm])->row_array();
            echo $result['jabatan'];
            ?>
        </td>
    </tr>
    <tr>
        <td>Bulan</td>
        <td>:</td>
        <td>
            <?php
            $result = $this->db->get_where('tbl_hari_efektif', ['id' => $bulan])->row_array();
            echo $result['bulan'];
            ?>
        </td>
    </tr>
</table>
<!-- <p>Daftar kegiatan pada :<?= date('m', $date = '2020-02-03'); ?></p> -->
<table class="table" width="100%" border="1" cellspacing="">
    <thead>
        <tr>
            <th width="25px">No.</th>
            <th width="70px">Jam</th>
            <th>Kegiatan</th>
            <th width="100px">Dokementasi</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($data as $d) : ?>
            <tr>
                <td valign="top" align="center"><?= $i; ?></td>
                <td valign="top"><?= $d['time']; ?></td>
                <td valign="top"><?= $d['kegiatan']; ?></td>
                <td><img src="<?= base_url('image/jurnal/' . $d['foto']); ?>" width="100px" height="100px"></td>
            </tr>
            <?php $i++; ?>
        <?php endforeach; ?>
    </tbody>
</table>