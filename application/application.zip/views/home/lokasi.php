<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Rumah ane pas didepan ini gan</title>
    <?php echo $map['js']; ?>
</head>

<body>
    <?php echo $map['html']; ?>
    <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAhqJLsq-fGh7bUPtizrau0GCfU7XyUgsE&callback=initMap" async defer></script> -->
</body>

</html>