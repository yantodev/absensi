Selamat datang <?= $user['name']; ?>
<?= $this->session->flashdata('message'); ?>